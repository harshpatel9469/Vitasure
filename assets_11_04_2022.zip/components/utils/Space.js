import React from 'react';
import {View} from 'react-native';

export default Space = (props) => <View style={{height: props.height || 20}}></View>