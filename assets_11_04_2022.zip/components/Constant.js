export const Colors = {
    primary: '#eb6199',
    grey: "#eee",
    white: "#fff",
    darkGray:"#696969"
}

export const API_URL= "https://dev.vitasure.net/wp-json"